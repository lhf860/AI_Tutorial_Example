# poker cards > 2024-06-04 12:47pm
https://universe.roboflow.com/roboflow-jvuqo/poker-cards-fmjio

Provided by a Roboflow user
License: CC BY 4.0

